<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbName="dbtest1";
    $conn = new mysqli($host,$user,$password,$dbName);
   
    $sql = "SELECT id, name, family, age FROM t_users where id=".$_GET['id'];
    $result = $conn->query($sql);


    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        $array1 = array('id'=>$row["id"], 'name'=>$row["name"], 'family'=>$row["family"],'age'=>$row["age"]);
        echo json_encode($array1);
      }
     } else {
      echo json_encode(array("id"=>0));
    }
    $conn->close();
    ?>