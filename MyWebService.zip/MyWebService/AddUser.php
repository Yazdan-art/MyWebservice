<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbName="dbtest1";
    $conn = new mysqli($host,$user,$password,$dbName);

    $name=$_GET['name'];
    $family=$_GET['family'];
    $age=$_GET['age'];
    $sql = "INSERT INTO t_users (name,family,age) VALUES ('$name','$family',$age)";
    if ($conn->query($sql) === TRUE) {
        echo "1";
    } else {
        echo "0";
    }
    
    $conn->close();
?>
