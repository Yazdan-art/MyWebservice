<?php
    $array1 = array('id'=>100, 'name'=>"mehdi", 'family'=>"abbasi",'age'=>34);
    echo json_encode($array1);
?>
