<?php
    $host="localhost";
    $user="root";
    $password="";
    $dbName="dbtest1";
    $conn = new mysqli($host,$user,$password,$dbName);

    $params = (array) json_decode(file_get_contents('php://input'), TRUE);
    $name=$params['name'];
    $family=$params['family'];
    $age=$params['age'];
    $sql = "INSERT INTO t_users (name,family,age) VALUES ('$name','$family',$age)";
    if ($conn->query($sql) === TRUE) {
        echo "1";
    } else {
        echo "0";
    }
    
    $conn->close();
?>